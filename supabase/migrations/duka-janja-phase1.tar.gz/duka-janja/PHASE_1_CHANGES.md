# Phase 1: Backend & Architecture Upgrade

This is phase 1 of the full marketplace rebuild. Your existing schema and code were already
solid (sellers, products, orders, RLS, stock triggers, commissions) — this phase extends it
rather than replacing it.

## What's new

### Database (`supabase/migrations/003_production_upgrade.sql`)
- `product_videos` table + `product-videos` storage bucket
- Seller verification: `seller_verification_documents` table, private `seller-verification`
  storage bucket, `seller_is_verified()` helper for the "Verified Seller" badge
- `payment_transactions` table — provider-agnostic (mpesa / airtel_money / tigo_pesa / cash_on_delivery)
- `delivery_tracking_events` — lat/lng + status history per order
- `recently_viewed` table + `track_recently_viewed()` RPC (auto-trims to last 50)
- `testimonials` table (curated, separate from product reviews)
- `policy_pages` table, seeded with a Returns & Refunds policy (EN + SW)
- Products gained `location_area`, `pickup_available`, `delivery_available`
- Sellers gained `location_area`, `national_id_verified`, `business_license_verified`

**Run this migration in the Supabase SQL editor after 001 and 002.**

### Code
- `src/types/index.ts` — types for everything above
- `src/lib/payments/` — provider-agnostic payment architecture:
  - `types.ts` — `PaymentProviderAdapter` interface
  - `providers/mpesa.ts`, `airtel_money.ts`, `tigo_pesa.ts` — stub adapters that clearly
    report "not configured" instead of faking success. Drop in real API calls once you
    have merchant credentials.
  - `index.ts` — registry (`getPaymentAdapter(provider)`)
- `src/app/api/payments/initiate/route.ts` — starts a payment for an order (cash on
  delivery works today; mobile money returns a clear "not configured" error until you add credentials)
- `src/app/api/payments/webhook/route.ts` — receiver for provider callbacks, marks orders paid
- `src/components/shared/VideoUploader.tsx` — sibling to your existing `ImageUploader`
- `src/hooks/useRecentlyViewed.ts` — `useTrackRecentlyViewed(productId)` to call on product
  pages, and `useRecentlyViewed()` to render a "Recently viewed" row

## What's next (phase 2+)
- Wire `VideoUploader` + multi-image upload into `ProductForm`
- Seller verification UI (upload ID/license, admin review queue)
- Homepage redesign + Recently Viewed / Related Products sections
- Checkout flow updated to call `/api/payments/initiate`
- Verified badge + ratings/testimonials shown on storefronts
